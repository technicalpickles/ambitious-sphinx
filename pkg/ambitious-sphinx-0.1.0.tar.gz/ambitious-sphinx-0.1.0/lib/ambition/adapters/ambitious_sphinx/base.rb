module Ambition
  module Adapters
    module AmbitiousSphinx
      class Base
        ##
        # Extract common functionality into this class.
        # All your classes, by default, inherit from this
        # one -- Query and the Translators.
      end
    end
  end
end